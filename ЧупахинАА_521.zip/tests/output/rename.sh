mv A3_NUMA_1_result.xml A2_NUMA_1_result.xml
mv A3_NUMA_1_result.txt A2_NUMA_1_result.txt
mv A3_NUMA_2_result.xml A2_NUMA_2_result.xml
mv A3_NUMA_2_result.txt A2_NUMA_2_result.txt
mv A3_NUMA_4_result.xml A2_NUMA_4_result.xml
mv A3_NUMA_4_result.txt A2_NUMA_4_result.txt


mv A4_NUMA_1_result.xml A3_NUMA_1_result.xml
mv A4_NUMA_1_result.txt A3_NUMA_1_result.txt
mv A4_NUMA_2_result.xml A3_NUMA_2_result.xml
mv A4_NUMA_2_result.txt A3_NUMA_2_result.txt
mv A4_NUMA_4_result.xml A3_NUMA_4_result.xml
mv A4_NUMA_4_result.txt A3_NUMA_4_result.txt


mv A5_NUMA_1_result.xml A4_NUMA_1_result.xml
mv A5_NUMA_1_result.txt A4_NUMA_1_result.txt
mv A5_NUMA_2_result.xml A4_NUMA_2_result.xml
mv A5_NUMA_2_result.txt A4_NUMA_2_result.txt
mv A5_NUMA_4_result.xml A4_NUMA_4_result.xml
mv A5_NUMA_4_result.txt A4_NUMA_4_result.txt
