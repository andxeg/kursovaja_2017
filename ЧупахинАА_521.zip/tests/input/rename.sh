mv A3_NUMA_1.dcxml A2_NUMA_1.dcxml
mv A3_NUMA_2.dcxml A2_NUMA_2.dcxml
mv A3_NUMA_4.dcxml A2_NUMA_4.dcxml

mv A4_NUMA_1.dcxml A3_NUMA_1.dcxml
mv A4_NUMA_2.dcxml A3_NUMA_2.dcxml
mv A4_NUMA_4.dcxml A3_NUMA_4.dcxml

mv A5_NUMA_1.dcxml A4_NUMA_1.dcxml
mv A5_NUMA_2.dcxml A4_NUMA_2.dcxml
mv A5_NUMA_4.dcxml A4_NUMA_4.dcxml